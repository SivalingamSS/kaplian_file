﻿namespace Temple_Service
{
    public class Modal
    {
        public int app_no { get; set; }
        public string dev_name { get; set; }
        public string mobile { get; set; }
    }
}
